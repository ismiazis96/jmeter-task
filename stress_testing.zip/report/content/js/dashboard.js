/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 25.860479409956977, "KoPercent": 74.13952059004302};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.17232636754763367, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.08681875792141952, 500, 1500, "Update Contact (PUT)"], "isController": false}, {"data": [0.0, 500, 1500, "Login User"], "isController": false}, {"data": [0.08522727272727272, 500, 1500, "Add Contact"], "isController": false}, {"data": [0.09472934472934473, 500, 1500, "Get Contact ID"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.09672830725462304, 500, 1500, "Update Contact (PATCH)"], "isController": false}, {"data": [0.08544303797468354, 500, 1500, "Get All Contact"], "isController": false}, {"data": [0.16504065040650406, 500, 1500, "Login User Data Set"], "isController": false}, {"data": [0.09557774607703282, 500, 1500, "Delete Contact ID"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 6508, 4825, 74.13952059004302, 6271.536724031968, 0, 40687, 758.0, 30253.0, 30260.0, 30402.82, 23.60665252008633, 26.786558368246368, 7.004215068828555], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Update Contact (PUT)", 789, 651, 82.50950570342205, 25171.558935361194, 908, 31268, 30253.0, 30312.0, 30382.0, 30718.9, 2.9619007218929134, 3.4567459611724476, 1.6837649819526772], "isController": false}, {"data": ["Login User", 801, 661, 82.52184769038702, 2703.383270911362, 2322, 4918, 2666.0, 2863.0, 3094.0999999999995, 3905.94, 3.3007244286573756, 2.493978064450662, 1.0290377342648986], "isController": false}, {"data": ["Add Contact", 792, 653, 82.44949494949495, 434.1994949494951, 249, 1618, 255.0, 1053.4, 1113.0499999999997, 1266.769999999993, 3.32903193264595, 2.7349636294329294, 1.9672127002358064], "isController": false}, {"data": ["Get Contact ID", 702, 566, 80.62678062678063, 868.8304843304841, 751, 2748, 765.0, 1094.7, 1147.0, 1787.3700000000006, 3.001603420630679, 2.4851266034206305, 0.807506012827365], "isController": false}, {"data": ["Debug Sampler", 615, 0, 0.0, 0.17723577235772375, 0, 17, 0.0, 1.0, 1.0, 1.0, 2.6731111101452174, 1.3399852326910624, 0.0], "isController": false}, {"data": ["Update Contact (PATCH)", 703, 566, 80.51209103840682, 210.73684210526326, 0, 1573, 1.0, 1069.6, 1130.9999999999998, 1182.8400000000001, 2.9954280309002046, 5.615682728832805, 0.34602929357112117], "isController": false}, {"data": ["Get All Contact", 790, 652, 82.53164556962025, 428.225316455696, 250, 2079, 255.0, 1086.0, 1139.35, 1229.7700000000018, 3.3331645655072317, 4.559957506107286, 0.8588452931708099], "isController": false}, {"data": ["Login User Data Set", 615, 511, 83.08943089430895, 129.8243902439024, 0, 2297, 1.0, 413.79999999999995, 458.19999999999993, 2016.7600000000004, 2.6550621025501546, 4.93712288809237, 0.3483251253059797], "isController": false}, {"data": ["Delete Contact ID", 701, 565, 80.59914407988587, 24635.07703281027, 906, 40687, 30253.0, 30303.6, 30395.3, 30973.22, 2.6122406391605058, 2.8922083040651834, 0.7840099011745767], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 1215, 25.181347150259068, 18.669330055316532], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: thinking-tester-contact-list.herokuapp.com:443 failed to respond", 1046, 21.678756476683937, 16.072526121696374], "isController": false}, {"data": ["401/Unauthorized", 2563, 53.119170984455955, 39.38229870928088], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, 0.02072538860103627, 0.015365703749231715], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 6508, 4825, "401/Unauthorized", 2563, "503/Service Unavailable", 1215, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: thinking-tester-contact-list.herokuapp.com:443 failed to respond", 1046, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Update Contact (PUT)", 789, 651, "503/Service Unavailable", 651, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Login User", 801, 661, "401/Unauthorized", 661, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Add Contact", 792, 653, "401/Unauthorized", 653, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Get Contact ID", 702, 566, "401/Unauthorized", 566, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Update Contact (PATCH)", 703, 566, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: thinking-tester-contact-list.herokuapp.com:443 failed to respond", 566, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Get All Contact", 790, 652, "401/Unauthorized", 652, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Login User Data Set", 615, 511, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: thinking-tester-contact-list.herokuapp.com:443 failed to respond", 480, "401/Unauthorized", 31, "", "", "", "", "", ""], "isController": false}, {"data": ["Delete Contact ID", 701, 565, "503/Service Unavailable", 564, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
